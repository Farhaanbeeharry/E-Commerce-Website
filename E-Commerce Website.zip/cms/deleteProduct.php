<?php
    //Start session management
    session_start();

        //read the data of the text box
    $productInputID= filter_input(INPUT_POST, 'productInputID', FILTER_SANITIZE_STRING);

    require __DIR__ . '/vendor/autoload.php';

    //connect to the database
    $mongoClient = (new MongoDB\Client);
    $db = $mongoClient->Tantalum;

    //the product id to delete
    $deleteCriteria = [
        "ProductID" => $productInputID
     ];

//perform delete
    $deleteRes = $db->Products->deleteOne($deleteCriteria);

    //if success, refresh the product page
    if ($deleteRes->getDeletedCount() == 1) {
        echo '<script>window.location.href="product.html";</script>'; 
        
    } else {
        echo '<script>alert("Product ID not found!");</script>'; 
        echo '<script>window.location.href="product.html";</script>'; 
        
    }

?>