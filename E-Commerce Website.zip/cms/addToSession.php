<?php
//start session
session_start();

//read the data input in the text box
$addToSession= filter_input(INPUT_POST, 'productInputID', FILTER_SANITIZE_STRING);

//add the temporary id to the session
$_SESSION["temporaryID"]=$addToSession;

//open the edit product page
echo '<script>window.location.href="edit_product.html";</script>';  
?>