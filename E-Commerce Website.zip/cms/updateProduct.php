<?php
    require __DIR__ . '/vendor/autoload.php';
    session_start();
    //Get name and address strings - need to filter input to reduce chances of SQL injection etc.
    $productID= filter_input(INPUT_POST, 'productIDInput', FILTER_SANITIZE_STRING);
    $productName = filter_input(INPUT_POST, 'productNameInput', FILTER_SANITIZE_STRING);
    $quantity = filter_input(INPUT_POST, 'quantityInput', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'descriptionInput', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, 'priceInput', FILTER_SANITIZE_NUMBER_INT);
    
    //STORE REGISTRATION DATA IN MONGODB
        //Create instance of MongoDB client
    $mongoClient = (new MongoDB\Client);
    

    //Select a database
    $db = $mongoClient->Tantalum;
    $id=$_SESSION['temporaryID'];
    $findCriteria = [
        "ProductID" => $id 
    ];
    
    $updateCriteria =[

        "ProductID" => $productID,
        "ProductName" => $productName,
        "Quantity" => $quantity,
        "Description" => $description,
        "Price" => $price,

    ];

    $update = $db->Products->replaceOne($findCriteria,$updateCriteria);
    
