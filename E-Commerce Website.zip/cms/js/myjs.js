function myFunction() {
  $('#hot').carousel({
  		interval:   2000
  	});

    $('#other').carousel({
    		interval:   2000
    	});

      $('#lightnings').carousel({
          interval:   2000
        });
}


function addToSession() {
  
  var addSession = document.getElementById("toSession").value;

  if (addSession == "") {
    alert("Textfield cannot be empty");
  } else {
    
 sessionStorage.setItem("temporaryID", addSession);
  }
}