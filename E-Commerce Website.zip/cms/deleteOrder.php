<?php
    //Start session management
    session_start();

    //read the data of the text box
    $orderID= filter_input(INPUT_POST, 'orderID', FILTER_SANITIZE_STRING);

    require __DIR__ . '/vendor/autoload.php';

//connect the database     
    $mongoClient = (new MongoDB\Client);
    $db = $mongoClient->Tantalum;

    //the order ID to delete
    $deleteCriteria = [
        "OrderID" => $orderID
     ];

//perform delete
    $deleteRes = $db->Orders->deleteOne($deleteCriteria);

    //if deleted, refresh order page
    if ($deleteRes->getDeletedCount() == 1) {
        echo '<script>window.location.href="order.html";</script>'; 
        
    } else {
        echo '<script>alert("Order ID not found!");</script>'; 
        echo '<script>window.location.href="order.html";</script>'; 
        
    }

?>