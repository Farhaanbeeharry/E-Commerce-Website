<?php
    //Start session management
    session_start();

    require __DIR__ . '/vendor/autoload.php';

    //connect to the database
    $mongoClient = (new MongoDB\Client);
    $db = $mongoClient->Tantalum;

    //read all orders in the database
    $orders = $db->Orders->find();

    //send the data in JSON format
    echo json_encode(iterator_to_array($orders));

?>