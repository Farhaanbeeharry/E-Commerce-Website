<?php

//Include libraries
require __DIR__ . '/vendor/autoload.php';
session_start();

//Create instance of MongoDB client
$mongoClient = (new MongoDB\Client);

//Select a database
$db = $mongoClient->Tantalum;

//search for the id of the input
$id=$_SESSION['temporaryID'];
$findCriteria = [
    "ProductID" => $id 
];

//get the data of the selected id
$products = $db->Products->find($findCriteria);

//send the data in JSON format
echo json_encode(iterator_to_array($products));