<?php
    require __DIR__ . '/vendor/autoload.php';
    //Get name and address strings - need to filter input to reduce chances of SQL injection etc.
    $productID= filter_input(INPUT_POST, 'productID', FILTER_SANITIZE_STRING);
    $productName = filter_input(INPUT_POST, 'productName', FILTER_SANITIZE_STRING);
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $price = filter_input(INPUT_POST, 'price', FILTER_SANITIZE_STRING);
    $keywords = filter_input(INPUT_POST, 'keywords', FILTER_SANITIZE_STRING);
    $fileName = filter_input(INPUT_POST, 'fileName', FILTER_SANITIZE_STRING);
    
    //STORE REGISTRATION DATA IN MONGODB
        //Create instance of MongoDB client
    $mongoClient = (new MongoDB\Client);

    //Select a database
    $db = $mongoClient->Tantalum;


//creating an array with the data of the new product    
    $dataArr =[

        "ProductID" => $productID,
        "ProductName" => $productName,
        "Quantity" => $quantity,
        "Description" => $description,
        "Price" => $price,
        "Keywords" => $keywords,
        "image_url" => $fileName

    ];


    $product = $db->Products->insertOne($dataArr);
    
        //Output message confirming registration
        echo '<script>alert("Product added successfully.");</script>';
        echo '<script>window.location.href="product.html";</script>';  
 