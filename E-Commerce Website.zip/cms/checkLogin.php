<?php
    //Start session management
    session_start();

    //Get name and address strings - need to filter input to reduce chances of SQL injection etc.
    $staffName= filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);    

    require __DIR__ . '/vendor/autoload.php';



    //Connect to MongoDB and select database
    $mongoClient = (new MongoDB\Client);
    $db = $mongoClient->Tantalum;

    //Create a PHP array with our search criteria
    $findCriteria = [
        "StaffName" => $staffName, 
        "Password" => $password
     ];

    //Find all of the customers that match  this criteria
    //$cursor = $db->Staff->find($findCriteria);





    $collection=$db->Staff;

    //Find all of the customers that match  this criteria
    $count = $collection->count($findCriteria);
    //$cursor = $db->Customers->find($findCriteria);

    //Check that there is exactly one customer
    if($count == 0){
        echo '<script>alert("Invalid staff username or password");</script>';
        echo '<script>window.location.href="index.html";</script>';  
        return;
    }
    else if($count > 1){
        echo '<script>alert("Database error: Multiple customers have same username.");</script>';
        echo '<script>window.location.href="index.html";</script>';  
        return;
    } else if ($count == 1) {
        //Start session for this user
        $_SESSION['loggedInUsername'] = $staffName;
        echo '<script> sessionStorage.setItem("staffName", "' . $_SESSION['loggedInUsername'] . '");</script>';
        echo '<script>window.location.href="access.html";</script>';  
        
    }
     

  
    