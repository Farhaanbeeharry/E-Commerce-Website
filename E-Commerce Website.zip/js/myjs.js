function myFunction() {
  $('#hot').carousel({
      interval: 2000
  });

  $('#other').carousel({
      interval: 2000
  });

  $('#lightnings').carousel({
      interval: 2000
  });
}